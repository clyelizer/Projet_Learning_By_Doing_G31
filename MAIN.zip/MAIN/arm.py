#!/usr/bin/env python3
"""
arm.py — Contrôle du bras robotique 4-DOF (PiCar Agri).

Utilise le PCA9685 déjà initialisé par Move.py (adresse 0x5f).
Les servos sont sur les canaux 0-7, les moteurs sur 8-15.

Séquence de prélèvement :
  1. Descendre le bras (piquer le sol)
  2. Rester baissé 1 seconde
  3. Remonter le bras
  4. Pause de 2 secondes (robot prêt à continuer)
"""

import time

# ---------------------------------------------------------------------------
# Configuration des servos du bras (canaux PCA9685 0-7)
# ---------------------------------------------------------------------------
SERVO_ELBOW = 2         # canal du servo coude (mouvement vertical)

ANGLE_DOWN = -45
ANGLE_UP = 0

DESCENTE_DELAY = 0.8
SAMPLE_DURATION = 1.0
REMONTEE_DELAY = 0.8
POST_PAUSE = 2.0

# Calibration servo : largeur d'impulsion en µs
PULSE_MIN = 500         # -90°
PULSE_MID = 1500        #   0°
PULSE_MAX = 2500        # +90°


def _angle_to_duty(angle_deg):
    """Convertit un angle (-90..+90) en valeur duty PCA9685 (0-4095)."""
    pulse_us = PULSE_MID + (angle_deg / 90.0) * (PULSE_MAX - PULSE_MID)
    duty = int((pulse_us / 20000.0) * 4095)
    return max(0, min(4095, duty))


def _servo_write(pwm, channel, angle_deg):
    """Écrit l'angle sur un canal servo du PCA9685."""
    duty = _angle_to_duty(angle_deg)
    pwm.channels[channel].duty_cycle = duty


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------
_initialized = False


def init():
    """Initialise les servos en position neutre (Move.setup() doit être appelé avant)."""
    global _initialized
    if _initialized:
        return

    import Move
    pwm = Move.pwm_motor

    for ch in range(8):
        _servo_write(pwm, ch, 0.0)

    _initialized = True
    time.sleep(0.3)


def cleanup():
    """Remet le bras au neutre."""
    global _initialized
    if not _initialized:
        return
    import Move
    _servo_write(Move.pwm_motor, SERVO_ELBOW, ANGLE_UP)
    time.sleep(0.5)
    _initialized = False


def sample():
    """
    Séquence de prélèvement :
      descendre → 1s au sol → remonter → pause 2s
    """
    init()
    import Move
    pwm = Move.pwm_motor

    print("  Bras → descente")
    _servo_write(pwm, SERVO_ELBOW, ANGLE_DOWN)
    time.sleep(DESCENTE_DELAY)

    print("  Bras → prélèvement (1s au sol)...")
    time.sleep(SAMPLE_DURATION)

    print("  Bras → remontée")
    _servo_write(pwm, SERVO_ELBOW, ANGLE_UP)
    time.sleep(REMONTEE_DELAY)

    print("  Bras → pause 2s avant continuation...")
    time.sleep(POST_PAUSE)
