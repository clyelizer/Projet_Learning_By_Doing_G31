#!/usr/bin/env python3
"""
Move.py — Contrôle des moteurs DC via PCA9685 (Adeept PiCar-Pro).

API :
  setup()          → initialise le PCA9685 et les 4 moteurs
  move(speed, dir, turn, radius) → commande de mouvement
  motorStop()      → arrêt immédiat des moteurs
  destroy()        → libération des ressources
"""

import time
from board import SCL, SDA
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import motor

# Brochage moteurs sur le PCA9685 (Robot HAT V3.2)
MOTOR_M1_IN1 = 15
MOTOR_M1_IN2 = 14
MOTOR_M2_IN1 = 12
MOTOR_M2_IN2 = 13
MOTOR_M3_IN1 = 11
MOTOR_M3_IN2 = 10
MOTOR_M4_IN1 = 8
MOTOR_M4_IN2 = 9

M1_Direction = -1
M2_Direction = -1

FREQ = 50

# Instance PCA9685 partagée (initialisée par setup(), utilisable par arm.py)
pwm_motor = None


def _map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) / (in_max - in_min) * (out_max - out_min) + out_min


def setup():
    global motor1, motor2, motor3, motor4, pwm_motor
    i2c = busio.I2C(SCL, SDA)
    pwm_motor = PCA9685(i2c, address=0x5f)
    pwm_motor.frequency = FREQ

    motor1 = motor.DCMotor(pwm_motor.channels[MOTOR_M1_IN1],
                           pwm_motor.channels[MOTOR_M1_IN2])
    motor1.decay_mode = motor.SLOW_DECAY
    motor2 = motor.DCMotor(pwm_motor.channels[MOTOR_M2_IN1],
                           pwm_motor.channels[MOTOR_M2_IN2])
    motor2.decay_mode = motor.SLOW_DECAY
    motor3 = motor.DCMotor(pwm_motor.channels[MOTOR_M3_IN1],
                           pwm_motor.channels[MOTOR_M3_IN2])
    motor3.decay_mode = motor.SLOW_DECAY
    motor4 = motor.DCMotor(pwm_motor.channels[MOTOR_M4_IN1],
                           pwm_motor.channels[MOTOR_M4_IN2])
    motor4.decay_mode = motor.SLOW_DECAY


def motorStop():
    motor1.throttle = 0
    motor2.throttle = 0
    motor3.throttle = 0
    motor4.throttle = 0


def _Motor(channel, direction, motor_speed):
    if motor_speed > 100:
        motor_speed = 100
    elif motor_speed < 0:
        motor_speed = 0

    speed = _map(motor_speed, 0, 100, 0, 1.0)
    pwm_motor.frequency = FREQ

    if direction == -1:
        speed = -speed

    if channel == 1:
        motor1.throttle = speed
    elif channel == 2:
        motor2.throttle = speed
    elif channel == 3:
        motor3.throttle = speed
    elif channel == 4:
        motor4.throttle = speed


def move(speed, direction, turn, radius=0.6):
    """
    Commande les moteurs.

    speed     : 0..100
    direction : 1 = avant, -1 = arrière
    turn      : "left", "right", "no"
    radius    : ratio de braquage (0 < radius <= 1)
    """
    if speed == 0:
        motorStop()
        return

    if direction == 1:          # avant
        if turn == 'left':
            _Motor(1, M1_Direction, speed * radius)
            _Motor(2, M2_Direction, speed)
        elif turn == 'right':
            _Motor(1, M1_Direction, speed)
            _Motor(2, M2_Direction, speed * radius)
        else:
            _Motor(1, M1_Direction, speed)
            _Motor(2, M2_Direction, speed)
    elif direction == -1:       # arrière
        if turn == 'left':
            _Motor(1, -M1_Direction, speed * radius)
            _Motor(2, -M2_Direction, speed)
        elif turn == 'right':
            _Motor(1, -M1_Direction, speed)
            _Motor(2, -M2_Direction, speed * radius)
        else:
            _Motor(1, -M1_Direction, speed)
            _Motor(2, -M2_Direction, speed)


def destroy():
    motorStop()
    pwm_motor.deinit()
