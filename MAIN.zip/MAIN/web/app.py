#!/usr/bin/env python3
"""
app.py — Backend Flask de l'interface robot agricole.

Routes :
  /              → interface web (index.html)
  /api/state     → état persistant du robot
  /api/move      → commande manuelle (joystick)
  /api/collect   → prélèvement d'échantillon
  /api/deposit   → dépôt vers analyse
  /api/mission/start → lance mission autonome
  /api/mission/stop  → interrompt mission
  /api/missions  → historique des missions
  /api/samples   → historique des échantillons
  /api/logs      → historique des logs
  /api/events    → SSE (logs temps réel)

Mode :
  SIMULATE=1 (défaut) → utilise hardware/simulator.py
  SIMULATE=0          → utilise executor.py + arm.py (Raspberry Pi)
"""

import sys
import os
import json
import queue
import subprocess
import threading
import signal
import time

from flask import (
    Flask, render_template, request, jsonify, Response, stream_with_context
)

# ---------------------------------------------------------------------------
# Ajout du dossier web au path
# ---------------------------------------------------------------------------
_web_dir = os.path.dirname(os.path.abspath(__file__))
if _web_dir not in sys.path:
    sys.path.insert(0, _web_dir)

from database import (
    add_log, get_logs, get_state, set_state, get_all_state,
    create_mission, finish_mission, get_missions, get_mission,
    add_sample, get_samples,
)

# ---------------------------------------------------------------------------
# Choix du driver matériel
# ---------------------------------------------------------------------------
SIMULATE = os.environ.get("SIMULATE", "1").lower() in ("1", "true", "yes")

if SIMULATE:
    import hardware.simulator as hw
    add_log("info", "system", "Mode SIMULATION activé")
else:
    # Import des modules Adeept pour le Raspberry Pi
    _main_dir = os.path.join(_web_dir, "..")
    if _main_dir not in sys.path:
        sys.path.insert(0, _main_dir)
    import executor
    import arm
    hw = None  # On utilise executor + arm directement
    add_log("info", "system", "Mode RÉEL activé (Raspberry Pi)")

# ---------------------------------------------------------------------------
# Configuration Flask
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False

# File d'attente SSE — chaque client s'abonne
_log_queues: list[queue.Queue] = []

# Verrou pour l'exécution (empêche les collisions joystick + autonome)
_lock = threading.Lock()

# Référence au processus mission autonome (pour l'arrêter)
_mission_proc: subprocess.Popen | None = None
_mission_id: int | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _broadcast_log(level: str, source: str, message: str, details: dict = None):
    """Ajoute un log en DB + le pousse à tous les clients SSE."""
    add_log(level, source, message, details)
    payload = json.dumps({
        "level": level,
        "source": source,
        "message": message,
        "details": details,
        "timestamp": time.strftime("%H:%M:%S"),
    })
    dead: list[queue.Queue] = []
    for q in _log_queues:
        try:
            q.put_nowait(payload)
        except queue.Full:
            dead.append(q)
    for q in dead:
        _log_queues.remove(q)


def _cells_occupied() -> int:
    return int(get_state("cells_occupied", "0"))


def _set_cells(n: int):
    set_state("cells_occupied", str(n))


def _set_last_action(action: str):
    set_state("last_action", action)
    _broadcast_log("info", "robot", action)


# ---------------------------------------------------------------------------
# Routes — Interface
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html", simulate=SIMULATE)


# ---------------------------------------------------------------------------
# Routes — État
# ---------------------------------------------------------------------------

@app.route("/api/state")
def api_state():
    state = get_all_state()
    state["simulate"] = SIMULATE
    state["mission_running"] = _mission_proc is not None
    return jsonify(state)


# ---------------------------------------------------------------------------
# Routes — Contrôle manuel
# ---------------------------------------------------------------------------

@app.route("/api/move", methods=["POST"])
def api_move():
    """Commande joystick : direction, angle, durée."""
    data = request.get_json(force=True)
    direction = data.get("dir", "AVANCER")
    angle = data.get("angle", 90)
    t = float(data.get("t", 1.0))

    def _do():
        with _lock:
            if SIMULATE:
                if direction == "AVANCER":
                    hw.forward(40, t)
                else:
                    hw.rotate(40, "left", t)
                hw.stop()
            else:
                executor.run_command({"type": "forward", "duration": t})

    threading.Thread(target=_do, daemon=True).start()
    _set_last_action(f"Move {direction} angle={angle} t={t}s")
    return jsonify({"status": "ok"})


@app.route("/api/collect", methods=["POST"])
def api_collect():
    """Prélève un échantillon."""
    data = request.get_json(force=True) or {}
    n = int(data.get("n", 1))

    def _do():
        with _lock:
            for i in range(n):
                if SIMULATE:
                    hw.sample_sequence()
                else:
                    arm.sample()
                idx = _cells_occupied()
                add_sample(mission_id=0, waypoint_id=i+1, cell_number=idx+1)
                _set_cells(idx + 1)
                _broadcast_log("info", "robot", f"Échantillon {idx+1} prélevé")
                time.sleep(0.2)
        _set_last_action(f"Collecté {n} échantillon(s)")

    threading.Thread(target=_do, daemon=True).start()
    return jsonify({"status": "collecting", "n": n})


@app.route("/api/deposit", methods=["POST"])
def api_deposit():
    """Dépose les échantillons vers l'analyse."""
    data = request.get_json(force=True) or {}
    tpc = int(data.get("tpc", 1))
    ept = int(data.get("ept", 3))

    def _do():
        n = _cells_occupied()
        with _lock:
            _broadcast_log("info", "robot", f"Dépôt de {n} échantillons...")
            if SIMULATE:
                for _ in range(n):
                    hw.sample_sequence()
                    time.sleep(0.5)
            else:
                from deposit_logic import executer_depot_final
                executer_depot_final(n, tpc, ept)
            _set_cells(0)
        _set_last_action(f"Dépôt terminé ({n} échantillons)")

    threading.Thread(target=_do, daemon=True).start()
    return jsonify({"status": "depositing"})


# ---------------------------------------------------------------------------
# Routes — Mission autonome
# ---------------------------------------------------------------------------

@app.route("/api/mission/start", methods=["POST"])
def api_mission_start():
    """Lance une mission autonome (main.py) en tâche de fond."""
    global _mission_proc, _mission_id

    if _mission_proc is not None:
        return jsonify({"error": "Une mission est déjà en cours"}), 409

    data = request.get_json(force=True) or {}
    speed = int(data.get("speed", 40))
    map_file = data.get("map", "map.json")
    cal_file = data.get("calibration", "calibration.json")

    _mission_id = create_mission(speed, map_file, cal_file)
    _broadcast_log("info", "mission", f"Mission #{_mission_id} lancée (speed={speed})")

    # Chemin absolu vers main.py
    main_py = os.path.join(_web_dir, "..", "main.py")

    def _run():
        global _mission_proc, _mission_id
        env = os.environ.copy()
        cmd = [sys.executable, main_py, "--speed", str(speed),
               "--map", map_file, "--calibration", cal_file]

        if SIMULATE:
            cmd.append("--dry-run")

        try:
            _mission_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, cwd=os.path.join(_web_dir, ".."),
                env=env
            )
            for line in iter(_mission_proc.stdout.readline, ""):
                line = line.rstrip()
                if line:
                    _broadcast_log("info", "mission", line)
            _mission_proc.wait()
            status = "completed" if _mission_proc.returncode == 0 else "aborted"
        except Exception as e:
            _broadcast_log("error", "mission", str(e))
            status = "aborted"
        finally:
            if _mission_id:
                finish_mission(_mission_id, status)
            _broadcast_log("info", "mission", f"Mission #{_mission_id} {status}")
            _mission_proc = None
            _mission_id = None

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"status": "started", "mission_id": _mission_id})


@app.route("/api/mission/stop", methods=["POST"])
def api_mission_stop():
    """Interrompt la mission en cours."""
    global _mission_proc
    if _mission_proc is None:
        return jsonify({"error": "Aucune mission en cours"}), 400
    _mission_proc.send_signal(signal.SIGINT)
    _broadcast_log("warning", "mission", "Interruption demandée")
    return jsonify({"status": "stopping"})


# ---------------------------------------------------------------------------
# Routes — Historique
# ---------------------------------------------------------------------------

@app.route("/api/missions")
def api_missions():
    return jsonify(get_missions(limit=request.args.get("limit", 20, int)))


@app.route("/api/samples")
def api_samples():
    mid = request.args.get("mission_id", None, int)
    return jsonify(get_samples(mission_id=mid))


@app.route("/api/logs")
def api_logs():
    level = request.args.get("level")
    return jsonify(get_logs(level=level))


# ---------------------------------------------------------------------------
# Server-Sent Events — Logs en temps réel
# ---------------------------------------------------------------------------

@app.route("/api/events")
def api_events():
    q: queue.Queue = queue.Queue(maxsize=256)
    _log_queues.append(q)

    def _stream():
        # Envoyer les logs récents au démarrage
        recent = get_logs(limit=20)
        for log in reversed(recent):
            yield f"data: {json.dumps(log, ensure_ascii=False)}\n\n"

        # Boucle d'attente des nouveaux logs
        while True:
            try:
                data = q.get(timeout=30)
                yield f"data: {data}\n\n"
            except queue.Empty:
                yield ": keepalive\n\n"

    return Response(
        stream_with_context(_stream()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# Démarrage
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if not SIMULATE:
        executor.init()
    else:
        hw.setup()

    _broadcast_log("info", "system",
                   f"Interface web démarrée (simulation={'ON' if SIMULATE else 'OFF'})")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
