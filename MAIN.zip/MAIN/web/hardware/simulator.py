#!/usr/bin/env python3
"""
simulator.py — Simulation matérielle pour développement sans Raspberry Pi.

Remplace les appels à Move.py et RPIservo.py par des logs et time.sleep
proportionnels, pour tester l'interface web sans matériel.
"""

import time
import sys
import os

# Chemin vers le dossier web pour les imports DB
_web_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _web_dir not in sys.path:
    sys.path.insert(0, _web_dir)

from database import add_log


def setup():
    add_log("info", "simulator", "Simulateur initialisé")


def forward(speed: int, duration: float):
    add_log("info", "simulator",
            f"AVANCE speed={speed} durée={duration}s")
    time.sleep(duration * 0.1)  # accéléré 10×


def rotate(speed: int, direction: str, duration: float):
    add_log("info", "simulator",
            f"TOURNE {direction} speed={speed} durée={duration}s")
    time.sleep(duration * 0.1)


def stop():
    add_log("info", "simulator", "ARRÊT moteurs")


def arm_down():
    add_log("info", "simulator", "Bras → descente")
    time.sleep(0.3)


def arm_up():
    add_log("info", "simulator", "Bras → remontée")
    time.sleep(0.3)


def arm_grab():
    add_log("info", "simulator", "Pince → fermeture")
    time.sleep(0.2)


def arm_release():
    add_log("info", "simulator", "Pince → ouverture")
    time.sleep(0.2)


def sample_sequence():
    """Séquence complète de prélèvement simulée."""
    arm_down()
    arm_grab()
    arm_up()
    arm_release()
    add_log("info", "simulator", "Prélèvement simulé terminé")


def cleanup():
    add_log("info", "simulator", "Simulateur arrêté")
