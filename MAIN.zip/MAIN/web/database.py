#!/usr/bin/env python3
"""
database.py — Couche de persistance SQLite pour l'interface web.

Tables :
  - missions    : missions autonomes (start, finish, statut, config)
  - samples     : échantillons prélevés (lien mission + waypoint)
  - logs        : événements horodatés (info, warning, error)
  - robot_state : paires clé/valeur persistantes (remplace le dict mémoire)
"""

import sqlite3
import os
import json
from datetime import datetime, timezone

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "robot.db")


# ---------------------------------------------------------------------------
# Initialisation / migration
# ---------------------------------------------------------------------------

def _dict_factory(cursor, row):
    """Convertit les lignes SQL en dicts."""
    cols = [col[0] for col in cursor.description]
    return dict(zip(cols, row))


def get_conn():
    """Retourne une connexion à la base (avec row factory dict)."""
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.row_factory = _dict_factory
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init_db():
    """Crée les tables si elles n'existent pas."""
    conn = get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS missions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at      TEXT NOT NULL,
            finished_at     TEXT,
            status          TEXT NOT NULL DEFAULT 'running'
                            CHECK (status IN ('running','completed','aborted')),
            speed           INTEGER DEFAULT 40,
            map_file        TEXT DEFAULT 'map.json',
            calibration_file TEXT DEFAULT 'calibration.json',
            waypoints_count INTEGER DEFAULT 0,
            notes           TEXT
        );

        CREATE TABLE IF NOT EXISTS samples (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            mission_id  INTEGER REFERENCES missions(id),
            waypoint_id INTEGER,
            collected_at TEXT NOT NULL DEFAULT (datetime('now')),
            status      TEXT NOT NULL DEFAULT 'collected'
                        CHECK (status IN ('collected','deposited','analyzed')),
            cell_number  INTEGER,
            tube_number  INTEGER
        );

        CREATE TABLE IF NOT EXISTS logs (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL DEFAULT (datetime('now')),
            level     TEXT NOT NULL DEFAULT 'info'
                      CHECK (level IN ('info','warning','error')),
            source    TEXT NOT NULL DEFAULT 'web',
            message   TEXT NOT NULL,
            details   TEXT
        );

        CREATE TABLE IF NOT EXISTS robot_state (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );

        INSERT OR IGNORE INTO robot_state (key, value)
        VALUES ('cells_occupied', '0');

        INSERT OR IGNORE INTO robot_state (key, value)
        VALUES ('last_action', 'Initialisé');
    """)
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Missions
# ---------------------------------------------------------------------------

def create_mission(speed=40, map_file="map.json",
                   calibration_file="calibration.json") -> int:
    """Crée une nouvelle mission et retourne son id."""
    conn = get_conn()
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        """INSERT INTO missions (started_at, speed, map_file, calibration_file)
           VALUES (?, ?, ?, ?)""",
        (now, speed, map_file, calibration_file)
    )
    conn.commit()
    row = conn.execute("SELECT last_insert_rowid()").fetchone()
    conn.close()
    return row["last_insert_rowid()"] if row else None


def finish_mission(mission_id: int, status="completed"):
    """Marque une mission comme terminée."""
    conn = get_conn()
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "UPDATE missions SET finished_at=?, status=? WHERE id=?",
        (now, status, mission_id)
    )
    conn.commit()
    conn.close()


def get_missions(limit=20):
    """Retourne les N dernières missions."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM missions ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return rows


def get_mission(mission_id: int):
    """Retourne une mission par son id."""
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM missions WHERE id=?", (mission_id,)
    ).fetchone()
    conn.close()
    return row


# ---------------------------------------------------------------------------
# Samples
# ---------------------------------------------------------------------------

def add_sample(mission_id: int, waypoint_id: int,
               cell_number: int = None) -> int:
    """Ajoute un échantillon prélevé."""
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO samples (mission_id, waypoint_id, cell_number)
           VALUES (?, ?, ?)""",
        (mission_id, waypoint_id, cell_number)
    )
    conn.commit()
    sample_id = cur.lastrowid
    conn.close()
    return sample_id


def get_samples(mission_id: int = None, limit=50):
    """Retourne les échantillons, filtrés par mission si fourni."""
    conn = get_conn()
    if mission_id:
        rows = conn.execute(
            "SELECT * FROM samples WHERE mission_id=? ORDER BY id DESC LIMIT ?",
            (mission_id, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM samples ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Logs
# ---------------------------------------------------------------------------

def add_log(level: str, source: str, message: str, details: dict = None):
    """Ajoute une entrée de log."""
    conn = get_conn()
    conn.execute(
        "INSERT INTO logs (level, source, message, details) VALUES (?, ?, ?, ?)",
        (level, source, message, json.dumps(details) if details else None)
    )
    conn.commit()
    conn.close()


def get_logs(limit=100, level=None):
    """Retourne les logs récents, filtrés par niveau si fourni."""
    conn = get_conn()
    if level:
        rows = conn.execute(
            "SELECT * FROM logs WHERE level=? ORDER BY id DESC LIMIT ?",
            (level, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Robot State (persistant)
# ---------------------------------------------------------------------------

def get_state(key: str, default=None):
    """Lit une valeur d'état persistante."""
    conn = get_conn()
    row = conn.execute(
        "SELECT value FROM robot_state WHERE key=?", (key,)
    ).fetchone()
    conn.close()
    if row is None:
        return default
    return row["value"]


def set_state(key: str, value: str):
    """Écrit une valeur d'état persistante."""
    conn = get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO robot_state (key, value) VALUES (?, ?)",
        (key, value)
    )
    conn.commit()
    conn.close()


def get_all_state():
    """Retourne tout l'état sous forme de dict."""
    conn = get_conn()
    rows = conn.execute("SELECT key, value FROM robot_state").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}


# ---------------------------------------------------------------------------
# Auto-init à l'import
# ---------------------------------------------------------------------------

init_db()
